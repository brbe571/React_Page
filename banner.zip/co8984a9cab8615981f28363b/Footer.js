import React from "react"

export default function Footer() {
    return (
        <nav className="Footer">
            <img src=""/>
            <img src=""/>
            <img src=""/>
            <img src=""/>
            <img src=""/>
        </nav>
    )
}