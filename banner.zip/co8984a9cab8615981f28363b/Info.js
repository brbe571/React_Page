import React from "react"

export default function Info() {
    return (
        <main>
            <img src=""/>
            <h1>Laura Smith</h1>
            <h2>Frontend Developer</h2>
            <h6>laurasmith.website</h6>
            <button>Email</button>
        </main>
    )
}